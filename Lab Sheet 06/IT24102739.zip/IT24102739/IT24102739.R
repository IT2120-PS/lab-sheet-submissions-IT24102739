setwd("C:/Users/DVM/OneDrive/Desktop/IT24102739")

# Question 1
# i. Binomial distribution with n=50 and p=0.85

# ii Probability that at least 47 students passed: P(X >= 47) = 1 - P(X <= 46)
1- pbinom(46, 50, 0.85, lower.tail = TRUE)

# Question 2
# i. Number of customer calls received in an hour

# ii. Poisson distribution with lambda=12

# iii. Probability of exactly 15 calls: P(X=15)
dpois(15, 12)

