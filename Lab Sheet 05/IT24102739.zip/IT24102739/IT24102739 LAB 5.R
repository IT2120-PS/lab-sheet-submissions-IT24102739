setwd("C:\\Users\\it24102739\\Downloads\\Lab 05-20250829")

#IMPORT DATA SET
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=" ")
attach(Delivery_Times)

#RENAMING COLUMNS
names(Delivery_Times)<-c("X1")
fix(Delivery_Times)
attach(Delivery_Times)

#DRAW HISTOGRAM
hist(X1,main = "Histogram for delivary times")
#HISTOGRAM
histogram <- hist(X1,main = "Histogram for delivary times",breaks = seq(20,70,length=10),right = FALSE)

# Assign class limits 
breaks <- round(histogram$breaks)
# Assign class frequencies
freq <- histogram$counts

# Assign mid point
mids <- histogram$mids
classes <- c()

for(i in 1:(length(breaks)-1)) {
  classes[i] <- paste0("[", breaks[i], ", ", breaks[i+1], ")")
}

# Obtaining frequency distribution 
cbind(Classes = classes, Frequency = freq)


lines(mids, freq)
# Draw frequency polygon 
plot(mids, freq, type = "l", main = "Frequency Polygon for delivary times", xlab = "Delivery times", ylab = "Frequency", ylim = c(0, max(freq)))

cum.freq <- cumsum(freq)
new <- c()

for(i in 1:length(breaks)) {
  if(i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

# Draw cumulative frequency polygon 
plot(breaks, new, type = "l", main = "Cumulative Frequency Polygon for Shareholders", 
     xlab = "Shareholders", ylab = "Cumulative Frequency", ylim = c(0, max(cum.freq)))

# Obtain upper limit 
cbind(Upper = breaks, CumFreq = new)